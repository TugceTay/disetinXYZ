/* Search */
function mySearchFunc() {
  const input = document.getElementById("mySearch");
  const filter = input.value.toUpperCase();
  const ul = document.getElementById("myMenu");
  const liItems = ul.getElementsByClassName("nav-item");
  Array.from(liItems).forEach(item => {
    const a = item.getElementsByTagName("a")[0];
    item.style.display = a.innerHTML.toUpperCase().includes(filter) ? "" : "none";
  });
}

/* Sidebar*/
const sidebarToggler = document.getElementById("docs-sidebar-toggler");
const sidebar = document.getElementById("docs-sidebar");
const sidebarLinks = document.querySelectorAll("#docs-sidebar .scrollto");

function responsiveSidebar() {
  if (window.innerWidth >= 1200) {
    sidebar.classList.remove("sidebar-hidden");
    sidebar.classList.add("sidebar-visible");
  } else {
    sidebar.classList.remove("sidebar-visible");
    sidebar.classList.add("sidebar-hidden");
  }
}

window.addEventListener("load", responsiveSidebar);
window.addEventListener("resize", responsiveSidebar);

if (sidebarToggler) {
  sidebarToggler.addEventListener("click", () => {
    sidebar.classList.toggle("sidebar-visible");
    sidebar.classList.toggle("sidebar-hidden");
  });
}

sidebarLinks.forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const targetId = link.getAttribute("href").substring(1);
    const targetElem = document.getElementById(targetId);
    if (targetElem) {
      targetElem.scrollIntoView({ behavior: "smooth" });
    }
    if (window.innerWidth < 1200) {
      sidebar.classList.remove("sidebar-visible");
      sidebar.classList.add("sidebar-hidden");
    }
  });
});



/* Particles JS */
particlesJS("particles-js", {
  "particles": {
    "number": { "value": 80 },
    "color": { "value": "#ffffff" },
    "shape": { "type": "circle" },
    "opacity": { "value": 0.5, "random": false },
    "size": { "value": 3, "random": true },
    "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 },
    "move": { "enable": true, "speed": 3, "direction": "none", "random": false, "straight": false, "out_mode": "out" }
  },
  "interactivity": {
    "events": {
      "onhover": { "enable": true, "mode": "repulse" },
      "onclick": { "enable": true, "mode": "push" }
    }
  },
  "retina_detect": true
});

/* demo talep */
document.getElementById('contactForm').addEventListener('submit', function (event) {
  event.preventDefault();
  const fullname = document.getElementById('fullname').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const message = document.getElementById('message').value.trim();

  if (!fullname || !email || !phone || !message) {
    alert("Lütfen tüm alanları doldurun.");
    return;
  }

  emailjs.sendForm('service_9o9aar8', 'template_ejq8941', this)
    .then(response => {
      alert("Mesajınız başarıyla gönderildi!");
      this.reset();
      const modalEl = document.getElementById('contactModal');
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
    })
    .catch(error => {
      alert("Mesaj gönderilirken bir hata oluştu, lütfen tekrar deneyin.");
    });
});


/* geri dönüş-öneri */
document.getElementById('feedBackForm').addEventListener('submit', function (event) {
  event.preventDefault();
 
  const feedbackEmail = document.getElementById('feedbackEmail').value.trim();
  const feedbackMessage = document.getElementById('feedbackMessage').value.trim();

  if (!feedbackEmail || !feedbackMessage) {
    alert("Lütfen tüm alanları doldurun.");
    return;
  }

  emailjs.sendForm('service_9o9aar8', 'template_ejq8941', this)
    .then(response => {
      alert("Mesajınız başarıyla gönderildi!");
      this.reset();
      const modalEl = document.getElementById('feedbackModal');
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
    })
    .catch(error => {
      alert("Mesaj gönderilirken bir hata oluştu, lütfen tekrar deneyin.");
    });
});




/* Bootstrap Tabs */
document.addEventListener("DOMContentLoaded", function () {
  const tabLinks = document.querySelectorAll('a[data-bs-toggle="tab"]');
  tabLinks.forEach(tab => {
    tab.addEventListener("click", event => {
      event.preventDefault();
      new bootstrap.Tab(tab).show();
    });
  });
});

/* jQuery Tab */
if (typeof $ !== 'undefined') {
  $('#myTab a').on('click', function (e) {
    e.preventDefault();
    $(this).tab('show');
  });
}





document.querySelectorAll('.section-wrapper').forEach(wrapper => {
  wrapper.addEventListener('mouseenter', () => {
    const section = wrapper.querySelector('section');
    if (section) {
      const id = section.getAttribute('id');
      const sidebarLink = document.querySelector(`#docs-sidebar .scrollto[href="#${id}"]`);
      if (sidebarLink) {
        sidebarLink.classList.add('highlight');
      }
    }
  });

  wrapper.addEventListener('mouseleave', () => {
    const section = wrapper.querySelector('section');
    if (section) {
      const id = section.getAttribute('id');
      const sidebarLink = document.querySelector(`#docs-sidebar .scrollto[href="#${id}"]`);
      if (sidebarLink) {
        sidebarLink.classList.remove('highlight');
      }
    }
  });
});


document.addEventListener("DOMContentLoaded", function () {
  // Ürün açıklama bölümlerini seçiyoruz (her bölümde "urun-section" sınıfı olduğunu varsayıyoruz)
  const sections = document.querySelectorAll(".urun-section");
  // Sidebar linklerini seçiyoruz (sidebar'nızın id'si "urunler-sidebar" olsun)
  const sidebarLinks = document.querySelectorAll("#urunler-sidebar .scrollto");

  function updateActiveSidebar() {
    const scrollPos = window.pageYOffset || document.documentElement.scrollTop;
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      // 100px ofset ile erken tetikleme sağlıyoruz
      if (scrollPos >= sectionTop - 100 && scrollPos < sectionTop + sectionHeight - 100) {
        const activeId = section.getAttribute("id");
        sidebarLinks.forEach(link => {
          if (link.getAttribute("href") === "#" + activeId) {
            link.classList.add("active");
          } else {
            link.classList.remove("active");
          }
        });
      }
    });
  }
  
  updateActiveSidebar();
  window.addEventListener("scroll", updateActiveSidebar);
});







